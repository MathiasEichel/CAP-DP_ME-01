/*
   Implementations for AdminService defined in ./admin-service.cds
*/
module.exports = cds.service.impl(async function () {

  // Entities for Product Master
  const { S4Products, aService_DownloadProducts, cldProducts, viewProducts } = this.entities    
  const Prodsrv = await cds.connect.to('API_PRODUCT_SRV')
  this.on('READ', S4Products, req => Prodsrv.tx(req).run(req.query))
  
  //Handler for Topic Product/Changed event 
  Prodsrv.on('Product/Changed', async (req) => {
    console.log('RECEIVED: Product/Changed') // logging confirm
    try{
      const pID = req.data.KEY[0].PRODUCT; const iCatGrp = req.data.KEY[0].ITEMCATEGORYGROUP; const matNumb = req.data.KEY[0].MANUFACTURERNUMBER
      const tx = cds.tx(req)  // get Transaction
      const affectedRows = await tx.run(UPDATE(cldProducts).set({iCatGrp: iCatGrp, matNumb: matNumb}) .where({pID: pID}))
      console.log('Product Updated', affectedRows)
    } catch (e) {
        console.log("Error: " + e.message)
        console.log("Stack: " + e.stack)
    }
  }) 
   
  //Handler for Topic: Product/Created event 
  Prodsrv.on('Product/Created', async (msg) => {
    const tx = cds.tx(msg) // get transaction
      console.log('RECEIVED: Product/Created') // logging confirm
    // get payload  
    const pID = msg.data.KEY[0].PRODUCT; const pType = msg.data.KEY[0].PRODUCTTYPE; const Status = msg.data.KEY[0].CROSSPLANTSTATUS; const soSupply = msg.data.KEY[0].SOURCEOFSUPPLY;  
    const pGroup = msg.data.KEY[0].PRODUCTGROUP; const UoM = msg.data.KEY[0].BASEUNIT; const iCatGrp = msg.data.KEY[0].ITEMCATEGORYGROUP; const matNum = msg.data.KEY[0].MANUFACTURERNUMBER;
    
    //----check if Product is new then insert ------
    try {
      const result = await tx.run(INSERT.into( cldProduts)
                  .columns['pID','pType','Status','soSupply','pGroup','UoM','iCatGrp,matNum']
                  .rows[pID,pType,Status,soSupply,pGroup,UoM,iCatGrp,matNum] )
      console.log('cloud Product inserted: ', result)            
    } catch(e) {
      console.log("Error: " + e.message)
      console.log("Stack: " + e.stack)      
    }
  })
  
  // handler for downloading Products --ok
  this.on('READ', aService_DownloadProducts, async (req) =>{
    const tx = cds.tx(req)
    const s4products = await Prodsrv.tx(req).run(SELECT.from(S4Products) )
    const result = await tx.run(INSERT.into( cldProducts).rows(s4products)) 
    console.log('Products uploaded. ')
  })
})
